<?php

/**
 * Interface Tribe__Editor__Meta_Interface
 *
 * @since 4.8
 */
interface Tribe__Editor__Meta_Interface {
	/**
	 * @since 4.8
	 *
	 * @return mixed
	 */
	public function register();
}
